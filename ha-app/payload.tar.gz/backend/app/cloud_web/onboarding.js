const $=id=>document.getElementById(id), staff=location.pathname==='/admin/hubs';
let csrf='', active='', activation=null, busy=false, kitURL=null, wizardStep=0, profileOnly=false;
const candidateDevice=new URLSearchParams(location.search).get('device')||'';
const selectedDevice=/^[0-9a-f-]{36}$/.test(candidateDevice)?candidateDevice:'';
const sections=['welcome','scan','auth','setup','progress','factory','verification'];
function show(id){for(const s of sections)$(s).hidden=s!==id;window.scrollTo({top:0,behavior:'instant'});}
function el(tag,text){const n=document.createElement(tag);if(text!==undefined)n.textContent=text;return n;}
const errors={hub_still_linked:'Huben er fortsatt knyttet til en konto og kan ikke slettes.',hub_operation_in_progress:'Vent til oppsettet eller tilbakestillingen er fullført før du sletter huben.',hub_not_found:'Huben finnes ikke lenger. Oppdater listen.',enrollment_offline:'Huben er funnet lokalt, men har ikke kontakt med SMARTi på internett ennå. Kontroller nettverkskabelen, vent litt og prøv igjen.',enrollment_not_ready:'Home Assistant starter fortsatt, eller huben har allerede SMARTi-brukere. Vent til den er klar, eller bruk eksisterende innlogging.',device_already_linked:'Denne huben er allerede koblet til en annen installasjon.',hub_already_personalized:'Denne etiketten er allerede knyttet til en annen hub. Velg riktig QR-kode eller kontakt support.',home_has_an_owner:'Denne huben tilhører allerede en annen konto. Be eieren om hjelp; etiketten gir ikke eierskap.',hub_not_ready_or_offline:'Huben er ikke leveringsklar eller er ikke på nett. Kontroller strøm og nettverkskabel, og prøv igjen.',factory_checks_incomplete:'Huben må være på nett, ha kontakt med Home Assistant og ha null SMARTi-brukere. Alle kontrollpunktene må bekreftes.',activation_not_found:'Vi fant ikke denne kombinasjonen av etikett og aktiveringskode. Kontroller kortet i esken. Hvis du brukte lokalt søk, søk på nytt – funnet kan ha utløpt.',password_confirmation_failed:'Passordet til SMARTi-kontoen stemmer ikke.',existing_users:'Huben har allerede en bruker. Velg eksisterende oppsett eller en bekreftet nullstilling.',no_existing_user:'Huben mangler en bruker. Fullfør oppstartsveilederen først.',serial_already_registered:'Serienummeret er allerede registrert.',setup_in_progress:'Oppsettet pågår allerede. Vent på resultatet før du gjør endringer.'};
async function api(path,method='GET',body,fallback='Kunne ikke fullføre. Oppsettet er lagret; prøv igjen.'){const r=await fetch('/api/'+path,{method,credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(20000)});if(path==="session"&&r.ok)document.documentElement.dataset.portalSession="authenticated";if(r.status===401||(path==="logout"&&r.ok))delete document.documentElement.dataset.portalSession;if(!r.ok){const d=await r.json().catch(()=>({}));throw new Error(errors[d.detail]||({401:'Logg inn for å fortsette.',403:'Tilgang mangler eller innloggingen er utløpt.',422:'Kontroller feltene. Nye passord trenger minst 12 tegn.',429:'For mange forsøk. Vent 15 minutter før du prøver igjen.'}[r.status])||fallback);}return r.json();}
async function run(fn){if(busy)return;busy=true;$('message').textContent='';document.body.classList.add('is-working');document.querySelectorAll('button').forEach(b=>b.disabled=true);try{await fn();}catch(e){$('message').textContent=e.name==='TimeoutError'?'Svaret tok for lang tid. Kontroller status før du prøver igjen.':e.message;}finally{document.body.classList.remove('is-working');busy=false;document.querySelectorAll('button').forEach(b=>b.disabled=false);if(!staff&&location.hash)queueMicrotask(resumeScannedActivation);}}
function parseLabel(value){let raw=value.trim();if(raw.startsWith('https://')){const u=new URL(raw);if(u.origin!=='https://home.smarti.dev'||u.pathname!=='/activate')throw Error('Dette er ikke en SMARTi-hubetikett.');raw=u.hash.slice(1);}const m=/^([0-9a-f-]{36})\.((?:(?:[0-9]{10}|v2)\.)?[0-9a-f]{64})$/.exec(raw);if(!m)throw Error('Skann hubetiketten eller lim inn hele lenken.');return {home:m[1],code:m[2]};}
async function current(){try{const s=await api('session');csrf=s.csrf;$('admin-nav').hidden=!s.portal_admin;$('generate-serial').hidden=!s.portal_admin;return true;}catch{return false;}}
$('identify').onsubmit=e=>{e.preventDefault();run(async()=>{const data=new FormData(e.target);activation={...parseLabel(data.get('label')),pin:data.get('pin'),...(selectedDevice?{device:selectedDevice}:{})};const h=await api('activation/'+activation.home+'/identify','POST',activation);$('identified').textContent=h.model+' · '+h.serial+(selectedDevice?' · Valgt hub '+selectedDevice.slice(-8):(h.online?' · Huben er på nett':' · Venter på nettverk'));if(await current())await claim();else show('auth');});};
async function verified(){
 if(!await current()){show('auth');return false;}
 const r=await api('customer/profile');
 if(!r.profile){profileOnly=true;window.smartiRegistration?.editProfile(false);show('auth');$('signup').hidden=false;$('login').hidden=true;$('signup').elements.password.required=false;$('signup').elements.password.closest('label').hidden=true;return false;}
 if(!r.profile.verified){show('verification');return false;}
 $('hub-username').value=(r.profile.full_name.trim().split(/\s+/)[0]||'admin').normalize('NFKC').replace(/[^\p{L}\p{N}_-]/gu,'').slice(0,64)||'admin';
 return true;
}
async function continueSetup(){if(!await verified())return;if(activation)await claim();else if(active)await status();else{show('scan');if($('identify').elements.label.value)setTimeout(()=>$('identify').requestSubmit(),0);}}
$('check-verification').onclick=()=>run(continueSetup);
$('resend-verification').onclick=()=>run(async()=>{await api('customer/verification','POST');$('message').textContent='Ny bekreftelse er sendt. Sjekk også søppelposten.';});
async function claim(){if(!await verified())return;if(!activation)throw Error('Skann etiketten først.');const r=await api('activation/'+activation.home+'/claim','POST',activation);active=r.id;activation=null;history.replaceState(null,'','/activate?home='+active);await status();}
async function login(register=false){const data=Object.fromEntries(new FormData($('login')));if(register)await api('register','POST',data);csrf=(await api('login','POST',data)).csrf;$('login').reset();if(staff){await current();show('factory');await inventory();}else await continueSetup();}
$('login').onsubmit=e=>{e.preventDefault();run(()=>login());};
$('show-register').onclick=()=>{$('signup').hidden=false;$('login').hidden=true;};
$('show-login').onclick=()=>{$('signup').hidden=true;$('login').hidden=false;};
$('signup').onsubmit=e=>{e.preventDefault();run(async()=>{const d=Object.fromEntries(new FormData(e.target));const password=d.password;delete d.password;const registration=window.smartiRegistration.payload();delete d.password_confirmation;delete d.terms_accepted;delete d.marketing_opt_in;d.photo=window.smartiProfilePhoto||'';if(profileOnly){await api('customer/profile','PUT',d);}else{await api('register','POST',{username:d.email,password,profile:d,...registration});csrf=(await api('login','POST',{username:d.email,password})).csrf;}e.target.reset();await continueSetup();});};
$('invite-form').onsubmit=e=>{e.preventDefault();run(async()=>{await api('customer/homes/'+active+'/invitations','POST',Object.fromEntries(new FormData(e.target)));$('invite-status').textContent='Invitasjonen er lagt i utsendingskøen. Du kan invitere flere eller åpne hjemmet.';e.target.reset();});};
$('open-home').onclick=e=>{if($('open-home').dataset.existing==='true')return;e.preventDefault();run(async()=>{const r=await api('customer/homes/'+active+'/open','POST');location.assign(r.url);});};
function room(name='',floor='Første etasje'){const row=el('div');row.className='room-row';for(const [title,value,key]of[['Rom',name,'room'],['Etasje',floor,'floor']]){const l=el('label',title),input=el('input');input.value=value;input.required=true;input.maxLength=80;input.dataset.field=key;l.append(input);row.append(l);}const remove=el('button','×');remove.type='button';remove.setAttribute('aria-label','Fjern rom');remove.onclick=()=>row.remove();row.append(remove);$('rooms').append(row);}
$('add-room').onclick=()=>room();for(const name of ['Stue','Kjøkken','Bad','Soverom'])room(name);
$('locate').onclick=()=>{if(!navigator.geolocation){$('message').textContent='Nettleseren støtter ikke posisjon. Fyll inn koordinatene manuelt.';return;}navigator.geolocation.getCurrentPosition(p=>{const f=$('configure');f.elements.latitude.value=p.coords.latitude;f.elements.longitude.value=p.coords.longitude;$('location-summary').textContent='Posisjonen er valgt. Kontroller at du er ved riktig hus.';},()=>{$('message').textContent='Posisjonen kunne ikke hentes. Tillat posisjon, eller skriv inn husets koordinater.';},{timeout:15000});};
function mode(){return $('existing-options').hidden?'new':$('configure').elements.mode.value;}
function updateMode(){const m=mode();$('setup-fields').hidden=m==='existing';$('setup-fields').querySelectorAll('input').forEach(x=>x.disabled=m==='existing');$('reset-warning').hidden=m!=='reset';$('hub-credentials').hidden=m==='existing';$('hub-credentials').querySelectorAll('input').forEach(i=>i.disabled=m==='existing');$('finish').textContent=m==='existing'?'Fortsett med hjemmet':'Gjør hjemmet klart';wizardStep=m==='existing'?3:0;showStep();}
$('configure').elements.mode.forEach(r=>r.onchange=updateMode);
$('configure').onsubmit=e=>{e.preventDefault();if(wizardStep<3){advance();return;}run(async()=>{const d=Object.fromEntries(new FormData(e.target)),m=mode();const body={mode:m,name:d.name||'Mitt hjem',latitude:Number(d.latitude||0),longitude:Number(d.longitude||0),timezone:d.timezone||'Europe/Oslo',country:d.country||'NO',experience:d.experience||'normal',rooms:m==='existing'?[]:[...$('rooms').children].map(row=>({name:row.querySelector('[data-field=room]').value.trim(),floor:row.querySelector('[data-field=floor]').value.trim()})),password:d.password||'',password_repeat:d.password_repeat||'',confirmation:d.confirmation||''};await api('onboarding/'+active,'POST',body);e.target.elements.password.value='';e.target.elements.password_repeat.value='';await status();});};
const stepNames={zwave_keys:"Sikrer Z-Wave-nettverket",radios:'Kobler til Zigbee og Z-Wave',checking:'Kontrollerer huben',resetting:'Nullstiller kundedata',location:'Lagrer hjem og posisjon',rooms:'Oppretter etasjer og rom',user:'Oppretter din bruker',completed:'Oppsett lagret'};
async function status(edit=false){const h=await api('onboarding/'+active),p=h.plan;
if(h.reset?.scan_required){active='';show('scan');$('scan-title').textContent='Skann hubens QR-kode på nytt';$('scan-hint').textContent='Eierskapet er beholdt. Skann etiketten under huben for å starte nytt oppsett med samme konto.';return;}
let report=document.getElementById('reset-report');if(!report){report=el('details');report.id='reset-report';$('hub-status').after(report);}report.replaceChildren();report.hidden=!h.reset?.report?.length;
if(!report.hidden){report.append(el('summary','Rapport fra tilbakestillingen'));for(const r of h.reset.report){const text=r.status==='done'?'Utført':'Må kontrolleres – fysisk nullstilling eller ny paring kan være nødvendig';report.append(el('p',r.name+' · '+text));}}
$('hub-status').textContent=h.model+' · '+h.serial+(h.online?' · Tilkoblet':' · Venter på nettverk');
if(p&&!edit){show('progress');$('progress-phase').textContent=p.status==='completed'?'4 · KLAR TIL BRUK':'4 · VI GJØR HJEMMET KLART';$('progress-title').textContent=p.status==='completed'?'Hjemmet ditt er satt opp.':p.status==='failed'?'Vi trenger litt hjelp.':'Huben tar over herfra.';$('progress-text').textContent=p.status==='failed'?(p.error==='zwave_keys_existing_devices'?'Z-Wave-kontrolleren har fortsatt parede enheter. Fjern disse manuelt før produksjonsoppsettet kan fortsette.':p.error==='zwave_keys_unavailable'?'Kunne ikke bekrefte de nye Z-Wave-nøklene. Kontroller at Z-Wave JS UI kjører, og prøv igjen. Kontakt support hvis dette fortsetter.':p.error==='radios_unavailable'?'Zigbee eller Z-Wave er ikke klar. Kontroller at Zigbee2MQTT, MQTT og Z-Wave JS UI kjører. Forbindelsene må være aktive før oppsettet kan fullføres. Ingen paringer er endret.':p.error==='ha_unavailable'?'Huben får ikke kontakt med Home Assistant. Kontroller at den har startet, og prøv igjen.':(stepNames[p.step]||'Oppsettet')+' kunne ikke fullføres. Det som allerede er lagret beholdes. Prøv igjen eller kontakt support.'):p.status==='completed'?(h.online&&h.remote_connected?(p.draft.mode==='existing'?'Oppsettet er beholdt. Åpne hjemmet med din eksisterende bruker.':'Alt er klart. Du er innlogget og kan åpne hjemmet ditt.'):'Oppsettet er lagret. Vi venter fortsatt på at fjernforbindelsen blir klar.'):!h.online?'Huben er ikke på nett. Kontroller strøm og nettverkskabel. Vi venter og kontrollerer igjen.':stepNames[p.step]||'Venter på huben';$('steps').hidden=p.status==='completed';$('steps').replaceChildren();for(const key of ['checking','location','rooms','user']){const item=el('li',stepNames[key]);const keys=['checking','location','rooms','user'];const at=keys.indexOf(p.step);item.className=p.status==='completed'||keys.indexOf(key)<at?'done':key===p.step?'working':'';if(item.className==='working')item.setAttribute('aria-current','step');$('steps').append(item);}$('open-home').hidden=!(p.status==='completed'&&h.online&&h.remote_connected);$('open-home').href='https://'+active+'.home.smarti.dev/';$('open-home').dataset.existing=String(p.draft.mode==='existing');$('invite-step').hidden=p.status!=='completed';$('retry').hidden=p.status!=='failed';$('manage-setup').hidden=p.status!=='completed'||p.draft.mode==='new';return;}
show('setup');$('existing-options').hidden=!(h.health.users>0);if(edit&&p){const d=p.draft,f=$('configure');for(const key of ['name','latitude','longitude','timezone','country'])f.elements[key].value=d[key]||(key==='country'?'NO':'');if(d.mode==='reset')f.elements.mode.value='reset';f.elements.experience.value=d.experience;$('rooms').replaceChildren();d.rooms.forEach(r=>room(r.name,r.floor));}updateMode();}
$('retry').onclick=()=>run(()=>status(true));$('manage-setup').onclick=()=>run(()=>status(true));
let fleetHubs=[];
async function inventory(){fleetHubs=await api('admin/hubs');await window.fleet.load(api,fleetHubs);renderInventory();}
function renderInventory(){const hubs=window.fleet.select(fleetHubs);window.fleet.mapItems(hubs);$('inventory').replaceChildren();for(const h of hubs){const card=el('article');card.className='hub-record';card.dataset.hub=h.id;const info=el('div');info.className='hub-info';const title=el('h2');const detailLink=el('button',h.serial);detailLink.type='button';detailLink.className='hub-detail-link';detailLink.onclick=()=>window.fleet.openDetails(h.id);title.append(detailLink);info.append(title,el('p',h.model+' · '+h.hardware),hubStatusNode(h));if(h.reset&&h.reset.phase!=='completed')info.append(el('p',(h.reset.ownership==='release_owner'?'Klargjøres for ny eier. Bruk samme QR-etikett ved nytt oppsett.':'Eieren beholdes. Bruk samme QR-etikett ved nytt oppsett.')+ (h.reset.qr_verified?' QR-koden er bekreftet.':'')));if(h.health.version)info.append(el('p','SMARTi '+h.health.version+' · '+h.health.users+' brukere · HA '+(h.health.ha_connected?'tilkoblet':'frakoblet')));const label=el('div');label.className='hub-label';const img=el('img');img.src='/api/admin/hubs/'+h.id+'/label';img.alt='QR-kode for '+h.serial;label.append(el('strong','SMARTi'),img,el('p',h.serial),el('small',h.model),el('small','Skann med SMARTi-appen'));const print=el('button','Skriv ut etikett');print.onclick=()=>{document.querySelectorAll('.printing').forEach(n=>n.classList.remove('printing'));label.classList.add('printing');window.print();};const actions=el('div');actions.className='hub-actions';const view=el('button','Se detaljer');view.type='button';view.onclick=()=>window.fleet.openDetails(h.id);actions.append(view,print);if(h.phase==='preparing'){const renew=el('button','Ny klargjøringsfil');renew.onclick=()=>{if(confirm('Erstatt hubens tilkoblingsnøkkel og aktiveringskode? Den gamle filen slutter å virke. Bruk den nye aktiveringskoden i oppsettet. Huben mottar tilkoblingen automatisk ved lokalt søk.'))run(async()=>{showKit(await api('admin/hubs/'+h.id+'/reprovision','POST'));await inventory();});};const more=el('details');more.className='hub-preparation';more.append(el('summary','Klargjør hub'));more.append(renew);const checks=el('form');checks.className='checks';for(const [key,title]of Object.entries({ha:'Home Assistant er klargjort',zigbee:'Zigbee-radio og Z2M er kontrollert',zwave:'Z-Wave-radio og UI er kontrollert',network:'Nettverk og hubidentitet er kontrollert',clean:'Ingen kundedata eller testhistorikk ligger igjen'})){const l=el('label'),i=el('input');i.type='checkbox';i.name=key;i.required=true;l.append(i,document.createTextNode(title));checks.append(l);}const ready=el('button','Godkjenn for levering');ready.className='primary';checks.append(ready);checks.onsubmit=e=>{e.preventDefault();run(async()=>{await api('admin/hubs/'+h.id+'/ready','POST',Object.fromEntries([...checks.querySelectorAll('input')].map(x=>[x.name,x.checked])));await inventory();});};more.append(checks);info.append(more);}const photo=el('img');photo.className='hub-photo';photo.src='/assets/smarti-hub.png';photo.alt='';photo.loading='lazy';info.append(window.fleet.versions(h));card.append(photo,info,window.fleet.metric(h),label,actions);$('inventory').append(card);}if(!hubs.length)$('inventory').append(el('p','Ingen huber å vise. Endre søket eller registrer en ny hub.'));}
$('new-hub').onsubmit=e=>{e.preventDefault();run(async()=>{const kit=await api('admin/hubs','POST',Object.fromEntries(new FormData(e.target)));showKit(kit);e.target.reset();$('serial-status').textContent='';await inventory();});};$('refresh').onclick=()=>run(inventory);if(staff){window.fleet.init(renderInventory);$('traffic-period').onchange=()=>run(inventory);}
if(selectedDevice){$('scan-title').textContent='Huben er funnet.';$('scan-hint').textContent='Valgt hub: '+selectedDevice.slice(-8)+'. Skann etiketten under huben. Vi kobler huben til kontoen din automatisk – du trenger ikke legge inn nøkler i Home Assistant.';}
const nativeDiscovery=window.webkit?.messageHandlers?.smartiOnboarding;
$('manual-discovery').hidden=!!nativeDiscovery;
$('discover-native').onclick=()=>{if(nativeDiscovery)nativeDiscovery.postMessage('discover');else $('browser-discovery').hidden=false;};
$('new-home').onclick=e=>{e.preventDefault();run(continueSetup);};
$('scan-native').onclick=()=>window.webkit?.messageHandlers?.smartiOnboarding?.postMessage('scan');
// WKWebView can navigate to a scanned fragment without reloading this document.
function readActivationFragment(){const fragment=location.hash.slice(1);history.replaceState(null,'',location.pathname+location.search);if(fragment){try{parseLabel(fragment);$('identify').elements.label.value=fragment;$('identify').elements.label.closest('label').hidden=true;$('scan-title').textContent='QR-koden er lest.';$('scan-hint').textContent='Skriv aktiveringskoden fra kortet i esken. Vi fortsetter automatisk når alle åtte sifrene er fylt inn.';$('identify').querySelector('button').textContent='Fortsett';if(parseLabel(fragment).code.startsWith('v2.')){$('identify').elements.pin.required=false;$('identify').elements.pin.closest('label').hidden=true;$('scan-hint').textContent='Vi bekrefter huben og kobler den til kontoen din.';}else{$('manual-discovery').hidden=false;$('manual-discovery').open=true;$('identify').elements.pin.focus();}}catch{$('message').textContent='QR-koden kunne ikke leses. Skann etiketten under huben på nytt.';}}}
function resumeScannedActivation(){
 if(staff||!location.hash||busy)return;
 run(async()=>{active='';activation=null;readActivationFragment();await continueSetup();});
}
window.addEventListener('hashchange',resumeScannedActivation);
(async()=>{if(staff){$('signup').hidden=true;$('login').hidden=false;if(await current()){show('factory');await run(inventory);}else show('auth');return;}if(location.pathname==='/welcome'){await run(continueSetup);return;}readActivationFragment();active=new URLSearchParams(location.search).get('home')||'';if(active&&!/^[0-9a-f-]{36}$/.test(active))active='';await run(continueSetup);$('scan-native').hidden=!window.webkit?.messageHandlers?.smartiOnboarding;})();
setInterval(()=>{if(active&&csrf&&!busy&&!document.hidden&&!$('progress').hidden)status().catch(e=>{$('message').textContent=e.message;});},5000);

const wizardSteps=['location-step','rooms-step','experience-step','review-step'];
function showStep(){wizardSteps.forEach((id,i)=>$(id).hidden=i!==wizardStep);$('back-step').hidden=wizardStep===0||mode()==='existing';$('next-step').hidden=wizardStep===3;[...$('wizard-progress').children].forEach((n,i)=>{n.classList.toggle('current',i===wizardStep);if(i===wizardStep)n.setAttribute('aria-current','step');else n.removeAttribute('aria-current');});}
function advance(){for(const input of $(wizardSteps[wizardStep]).querySelectorAll('input')){if(!input.checkValidity()){const d=input.closest('details');if(d)d.open=true;input.reportValidity();return;}}wizardStep=Math.min(3,wizardStep+1);showStep();$('setup').scrollIntoView({block:'start'});}
$('next-step').onclick=advance;$('back-step').onclick=()=>{wizardStep=Math.max(0,wizardStep-1);showStep();};

function showKit(kit){if(kitURL)URL.revokeObjectURL(kitURL);kitURL=URL.createObjectURL(new Blob([JSON.stringify(kit,null,2)],{type:'application/json'}));$('download-kit').href=kitURL;$('download-kit').download='SMARTi-klargjoring-'+kit.installation_id+'.json';$('factory-kit').hidden=false;}

$('generate-serial').onclick = async () => {
 if (!staff || busy) return;
 const input = $('factory-serial'), button = $('generate-serial'), form = $('new-hub');
 input.readOnly = true;
 button.textContent = 'Genererer…';
 form.dataset.generating = 'true';
 form.setAttribute('aria-busy', 'true');
 $('serial-status').textContent = '';
 try {
  await run(async () => {
   const result = await api('admin/hubs/serial', 'POST', undefined, 'Kunne ikke generere serienummer. Prøv igjen.');
   input.value = result.serial;
   $('serial-status').textContent = 'Serienummeret er klart. Velg «Registrer hub» når resten er fylt ut.';
  });
 } finally {
  input.readOnly = false;
  button.textContent = 'Generer';
  delete form.dataset.generating;
  form.removeAttribute('aria-busy');
  input.focus();
 }
};
$('factory-serial').addEventListener('input', () => { $('serial-status').textContent = ''; });

// The QR supplies the label; completing the separate PIN advances without another tap.
$('identify').elements.pin.addEventListener('input',()=>{
 const form=$('identify');
 if(!/^[0-9]{8}$/.test(form.elements.pin.value)||busy)return;
 try{parseLabel(form.elements.label.value);}catch{return;}
 form.requestSubmit();
});

function hubPhase(h){
 const phase=h.reset?.phase;
 if(phase==='erasing')return 'Tilbakestilling pågår';
 if(phase==='rebooting')return 'Tilbakestilt · huben starter på nytt';
 if(phase==='failed')return 'Tilbakestilling avbrutt · trenger oppfølging';
 if(phase==='awaiting_owner'){
  if(h.setup_status==='failed')return 'Nytt oppsett trenger oppfølging';
  if(['queued','working'].includes(h.setup_status))return 'Nytt oppsett pågår';
  return h.reset.qr_verified?'QR bekreftet · venter på nytt oppsett':h.reset.ownership==='release_owner'?'Frigjort · venter på ny eier og QR-skanning':'Tilbakestilt · venter på ny QR-skanning';
 }
 return ({preparing:'Under klargjøring',ready:'Klar for levering',activated:'Aktivert',resetting:'Tilbakestilling pågår',awaiting_owner:'Tilbakestilt · venter på ny QR-skanning',rebooting:'Huben starter på nytt'}[h.phase]||h.phase);
}

const homeCountries='AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW'.split(' '),homeCountryNames=new Intl.DisplayNames(['nb'],{type:'region'}),homeCountrySelect=$('configure').elements.country;homeCountrySelect.replaceChildren(...homeCountries.map(code=>({code,name:homeCountryNames.of(code)})).sort((a,b)=>a.name.localeCompare(b.name,'nb')).map(c=>new Option(c.name,c.code)));homeCountrySelect.value='NO';

function updateHubStatus(node,h){
 const complete=(!h.reset||h.reset.phase==='completed')&&(h.setup_status==='completed'||(!h.setup_status&&h.phase==='activated'));
 node.classList.toggle('hub-onboarded',complete);node.replaceChildren();
 if(complete){const check=el('span');check.className='hub-complete-check';check.setAttribute('aria-hidden','true');node.append(check);}
 node.append(document.createTextNode(complete?'Oppsett fullført':hubPhase(h)));
 const connection=el('span',' · '+(h.online?'På nett':'Frakoblet'));connection.className='hub-connection-status';node.append(connection);
}
function hubStatusNode(h){const node=el('p');node.dataset.hubStatus=h.id;node.setAttribute('role','status');updateHubStatus(node,h);return node;}
let inventoryPolling=false;
setInterval(async()=>{if(!staff||!csrf||busy||inventoryPolling||document.hidden||$('factory').hidden)return;inventoryPolling=true;try{const hubs=await api('admin/hubs');for(const node of document.querySelectorAll('[data-hub-status]')){const h=hubs.find(h=>h.id===node.dataset.hubStatus);if(h)updateHubStatus(node,h);}}catch(e){$('message').textContent=e.message;}finally{inventoryPolling=false;}},10000);

if(staff){
 document.title='SMARTi · Hubadministrasjon';
 document.querySelector('#auth .eyebrow').textContent='SMARTi ADMINISTRASJON';
 document.querySelector('#auth h1').textContent='Logg inn som administrator.';
 document.querySelector('#auth > p:not([class]):not([id])').textContent='Bruk administratorkontoen din for å se og klargjøre huber.';
 document.querySelector('#auth .choices').hidden=true;
}
let fleetRefreshBusy=false;
setInterval(async()=>{
 if(!staff||!csrf||busy||fleetRefreshBusy||document.hidden||$('factory').hidden)return;
 fleetRefreshBusy=true;
 try{fleetHubs=await api('admin/hubs');await window.fleet.load(api,fleetHubs);window.fleet.mapItems(window.fleet.select(fleetHubs));for(const card of document.querySelectorAll('[data-hub]')){const h=fleetHubs.find(h=>h.id===card.dataset.hub);if(h){card.querySelector('.hub-traffic')?.replaceWith(window.fleet.metric(h));card.querySelector('.hub-versions')?.replaceWith(window.fleet.versions(h));}}}
 catch(e){$('message').textContent=e.message;}finally{fleetRefreshBusy=false;}
},60000);
