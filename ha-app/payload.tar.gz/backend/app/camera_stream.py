"""User-bound HLS relay. HA stream URLs and credentials never reach the browser."""

import asyncio
import re
import secrets
import time
from collections import OrderedDict
from contextlib import asynccontextmanager
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from fastapi.responses import StreamingResponse

from .ha import HAError


class CameraStreams:
    def __init__(self, ha, demo=False):
        self.ha, self.demo = ha, demo
        self.sessions = {}
        self.lock = asyncio.Lock()
        self.pending = {}
        self.client = httpx.AsyncClient(
            timeout=25,
            follow_redirects=False,
            trust_env=False,
            limits=httpx.Limits(max_connections=64, max_keepalive_connections=32),
        )

    async def close(self):
        await self.client.aclose()

    def prune(self):
        now = time.monotonic()
        self.sessions = {
            k: s for k, s in self.sessions.items() if now - s["used"] < 120 and now - s["created"] < 3600
        }

    def upstream_url(self, base, value):
        """Keep HA's canonical API paths behind the configured Supervisor prefix."""
        parsed = urlsplit(urljoin(base, value))
        upstream = urlsplit(self.ha.http_url)
        if (parsed.scheme, parsed.netloc) == (upstream.scheme, upstream.netloc) and parsed.path.startswith(
            "/api/hls/"
        ):
            parsed = parsed._replace(path=upstream.path + parsed.path.removeprefix("/api/"))
        return urlunsplit(parsed)

    async def start(self, entity_id, owner):
        sid = secrets.token_urlsafe(24)
        async with self.lock:
            self.prune()
            if self.demo or not self.ha.connected:
                raise HTTPException(503, "live_stream_unavailable")
            owners = [s["owner"] for s in self.sessions.values()] + list(self.pending.values())
            if len(owners) >= 32 or owners.count(owner) >= 4:
                raise HTTPException(429, "stream_limit")
            self.pending[sid] = owner
        # Reserve capacity under the lock, but do not serialize camera startup.
        try:
            try:
                result = await self.ha.request(
                    "camera/stream", entity_id=entity_id, format="hls", _timeout=30
                )
                source = self.upstream_url(self.ha.http_url, result["url"])
                parsed = urlsplit(source)
                base = urlsplit(self.ha.http_url)
                match = re.fullmatch(
                    r"(" + re.escape(base.path) + r"hls/[a-f0-9]+/)([\w-]+\.m3u8)", parsed.path
                )
                if (
                    (parsed.scheme, parsed.netloc) != (base.scheme, base.netloc)
                    or not match
                    or parsed.fragment
                ):
                    raise ValueError()
            except (HAError, TimeoutError, KeyError, TypeError, ValueError):
                raise HTTPException(503, "live_stream_unavailable") from None
            now = time.monotonic()
            self.sessions[sid] = {
                "owner": owner,
                "entity_id": entity_id,
                "root": match[1],
                "created": now,
                "used": now,
                "resources": OrderedDict(),
            }
            rid = self.resource(self.sessions[sid], source, source)
            return {"id": sid, "path": f"home/camera-stream/{sid}/{rid}"}
        finally:
            self.pending.pop(sid, None)

    def session(self, sid, owner):
        self.prune()
        s = self.sessions.get(sid)
        if not s or s["owner"] != owner:
            raise HTTPException(404, "stream_expired")
        s["used"] = time.monotonic()
        return s

    def resource(self, session, base, value):
        url = self.upstream_url(base, value)
        parsed, upstream = urlsplit(url), urlsplit(self.ha.http_url)
        suffix = parsed.path.removeprefix(session["root"])
        if (
            (parsed.scheme, parsed.netloc) != (upstream.scheme, upstream.netloc)
            or not parsed.path.startswith(session["root"])
            or parsed.fragment
            or not re.fullmatch(r"[\w/.-]+\.(?:m3u8|mp4|m4s|ts)", suffix)
            or ".." in suffix
            or parsed.username
        ):
            raise HTTPException(502, "invalid_stream_resource")
        resources = session["resources"]
        for rid, known in resources.items():
            if known == url:
                resources.move_to_end(rid)
                return rid
        rid = secrets.token_urlsafe(18)
        resources[rid] = url
        while len(resources) > 512:
            resources.popitem(last=False)
        return rid

    def source(self, session, rid, query):
        source = session["resources"].get(rid)
        if not source:
            raise HTTPException(404, "stream_resource_expired")
        params = dict(query)
        if any(
            k not in {"_HLS_msn", "_HLS_part", "_HLS_skip"} or not re.fullmatch(r"\d{1,12}|YES|v2", v)
            for k, v in params.items()
        ):
            raise HTTPException(422, "invalid_stream_query")
        parsed = urlsplit(source)
        url = urlunsplit(parsed._replace(query=urlencode(dict(parse_qsl(parsed.query)) | params)))
        return parsed, url

    async def media(self, session, rid, query, byte_range=None):
        parsed, url = self.source(session, rid, query)
        headers = {"Authorization": "Bearer " + self.ha.token}
        if byte_range:
            if not re.fullmatch(r"bytes=\d{1,12}-\d{0,12}", byte_range):
                raise HTTPException(422, "invalid_stream_range")
            headers["Range"] = byte_range
        try:
            upstream = await self.client.send(
                self.client.build_request("GET", url, headers=headers), stream=True
            )
        except httpx.HTTPError:
            raise HTTPException(502, "stream_unavailable") from None
        if upstream.status_code not in {200, 206}:
            status = 404 if upstream.status_code in {404, 410} else 502
            await upstream.aclose()
            raise HTTPException(status, "stream_unavailable")
        response_headers = {"Cache-Control": "private, no-store"}
        # Native HLS and LL-HLS can request byte ranges for initialization/parts.
        if upstream.status_code == 206:
            content_range = upstream.headers.get("content-range", "")
            if not byte_range or not re.fullmatch(r"bytes \d+-\d+/(?:\d+|\*)", content_range):
                await upstream.aclose()
                raise HTTPException(502, "invalid_stream_range")
            response_headers["Content-Range"] = content_range
            response_headers["Accept-Ranges"] = "bytes"

        async def chunks():
            length = 0
            try:
                async for chunk in upstream.aiter_bytes():
                    length += len(chunk)
                    if length > 16_000_000:
                        raise RuntimeError("stream_too_large")
                    yield chunk
            finally:
                await upstream.aclose()

        return StreamingResponse(
            chunks(),
            status_code=upstream.status_code,
            media_type="video/mp2t" if parsed.path.endswith(".ts") else "video/mp4",
            headers=response_headers,
        )

    async def fetch(self, session, rid, query):
        parsed, url = self.source(session, rid, query)
        playlist = parsed.path.endswith(".m3u8")
        limit = 512_000 if playlist else 16_000_000
        try:
            async with self.client.stream(
                "GET", url, headers={"Authorization": "Bearer " + self.ha.token}
            ) as upstream:
                if upstream.status_code != 200:
                    raise HAError("stream_unavailable")
                data = bytearray()
                async for chunk in upstream.aiter_bytes():
                    data.extend(chunk)
                    if len(data) > limit:
                        raise HAError("stream_too_large")
        except (httpx.HTTPError, HAError):
            raise HTTPException(502, "stream_unavailable") from None
        if not playlist:
            return bytes(data), "video/mp2t" if parsed.path.endswith(".ts") else "video/mp4"
        try:
            manifest = data.decode("utf-8")
            if not manifest.startswith("#EXTM3U"):
                raise ValueError()
            rewritten = []
            for line in manifest.splitlines():
                if line and not line.startswith("#"):
                    line = self.resource(session, url, line.strip())
                elif "URI=" in line:
                    line = re.sub(
                        r'URI="([^"]+)"', lambda m: 'URI="' + self.resource(session, url, m[1]) + '"', line
                    )
                rewritten.append(line)
            return ("\n".join(rewritten) + "\n").encode(), "application/vnd.apple.mpegurl"
        except (UnicodeDecodeError, ValueError):
            raise HTTPException(502, "invalid_stream_playlist") from None


def camera_router(ha, user, settings):
    streams = CameraStreams(ha, settings.mode == "demo")

    @asynccontextmanager
    async def lifespan(app):
        try:
            yield
        finally:
            await streams.close()

    router = APIRouter(prefix="/api/home", lifespan=lifespan)

    def owner(current):
        return current["id"], current["csrf"]

    def available(entity):
        c = next((c for c in ha.controls() if c.id == entity or c.entity_id == entity), None)
        if not c or c.domain != "camera":
            raise HTTPException(404, "camera_not_found")
        if c.availability != "available" or not ha.connected:
            raise HTTPException(503, "camera_unavailable")
        return c

    @router.post("/camera/{id}/live")
    async def start(id: str, current=Depends(user)):
        return await streams.start(available(id).entity_id, owner(current))

    @router.get("/camera-stream/{sid}/{rid}")
    async def resource(sid: str, rid: str, request: Request, current=Depends(user)):
        session = streams.session(sid, owner(current))
        available(session["entity_id"])
        parsed, _ = streams.source(session, rid, request.query_params)
        if not parsed.path.endswith(".m3u8"):
            return await streams.media(session, rid, request.query_params, request.headers.get("range"))
        data, media = await streams.fetch(session, rid, request.query_params)
        return Response(data, media_type=media, headers={"Cache-Control": "private, no-store"})

    @router.delete("/camera-stream/{sid}")
    async def stop(sid: str, current=Depends(user)):
        streams.session(sid, owner(current))
        streams.sessions.pop(sid, None)
        return {"stopped": True}

    return router
