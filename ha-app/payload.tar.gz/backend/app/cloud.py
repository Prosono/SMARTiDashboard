"""Multi-home account/enrollment control plane; does not proxy home commands."""

import asyncio
import base64
import contextlib
import hashlib
import os
import re
import secrets
import sqlite3
import threading
import time
import uuid
from contextlib import asynccontextmanager, contextmanager
from pathlib import Path

import httpx
from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pwdlib import PasswordHash
from pydantic import BaseModel, Field, field_validator, model_validator

from app.cloud_accounts import Profile, install_accounts, remote_allowed
from app.cloud_admin import install_admin
from app.cloud_onboarding import install_onboarding
from app.cloud_support import install_support
from app.session_policy import SESSION_COOKIE_SECONDS, SESSION_EXPIRY, persist_valid_sessions

PASSWORDS = PasswordHash.recommended()
PASSWORD_WORKERS = threading.BoundedSemaphore(2)
DUMMY = PASSWORDS.hash(secrets.token_urlsafe(32))


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


class Credentials(BaseModel):
    username: str = Field(min_length=3, max_length=254, pattern=r"^[a-zA-Z0-9_.@+-]+$")
    password: str = Field(min_length=1, max_length=256)


class HomePhoto(BaseModel):
    photo: str = Field(max_length=700000)

    @field_validator("photo")
    @classmethod
    def valid_photo(cls, value):
        return Profile.photo_valid(value)


TERMS_VERSION = "2026-10-22"


class Registration(Credentials):
    profile: Profile
    password_confirmation: str = Field(max_length=256)
    terms_version: str
    terms_accepted: bool = Field(strict=True)
    marketing_opt_in: bool = Field(default=False, strict=True)
    password: str = Field(min_length=12, max_length=256)

    @model_validator(mode="after")
    def email_identifier(self):
        if self.password != self.password_confirmation:
            raise ValueError("password_confirmation_mismatch")
        if not self.terms_accepted or self.terms_version != TERMS_VERSION:
            raise ValueError("terms_acceptance_required")
        if "@" in self.username and self.username.lower() != self.profile.email:
            raise ValueError("email_username_mismatch")
        return self


class HomeName(BaseModel):
    name: str = Field(min_length=1, max_length=80)


class Claim(BaseModel):
    code: str = Field(min_length=32, max_length=128)


class CertificateChallenge(BaseModel):
    model_config = {"extra": "forbid"}
    token: str = Field(pattern=r"^[A-Za-z0-9_-]{22,128}$")
    validation: str = Field(pattern=r"^[A-Za-z0-9_-]{22,128}\.[A-Za-z0-9_-]{43}$")


def create_cloud(database, provision_secret, origin="https://home.smarti.dev", relay_status_url=None):
    if len(provision_secret) < 32:
        raise ValueError("A separate random provisioning credential is required")
    if not origin.startswith("https://") or origin.endswith("/"):
        raise ValueError("An HTTPS origin without trailing slash is required")
    database = Path(database)
    database.parent.mkdir(parents=True, exist_ok=True)

    @contextmanager
    def db():
        connection = sqlite3.connect(database, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS accounts(
            id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS sessions(
            token TEXT PRIMARY KEY, account TEXT NOT NULL REFERENCES accounts(id),
            csrf TEXT NOT NULL, expires REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS homes(
            id TEXT PRIMARY KEY, name TEXT NOT NULL, credential TEXT NOT NULL,
            owner TEXT REFERENCES accounts(id));
        CREATE TABLE IF NOT EXISTS home_photos(
            home TEXT PRIMARY KEY REFERENCES homes(id) ON DELETE CASCADE,
            body BLOB NOT NULL, revision TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS claims(
            token TEXT PRIMARY KEY, home TEXT UNIQUE NOT NULL REFERENCES homes(id),
            expires REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS attempts(
            key TEXT PRIMARY KEY, count INTEGER NOT NULL, expires REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS certificate_challenges(
            home TEXT PRIMARY KEY REFERENCES homes(id), token TEXT NOT NULL,
            validation TEXT NOT NULL, expires REAL NOT NULL);
        """)
        columns = {row[1] for row in c.execute("PRAGMA table_info(homes)")}
        if "remote_enabled" not in columns:
            c.execute("ALTER TABLE homes ADD COLUMN remote_enabled INTEGER NOT NULL DEFAULT 1")
        persist_valid_sessions(c, "sessions")
    os.chmod(database, 0o600)

    @asynccontextmanager
    async def lifespan(app):
        async def mail_loop():
            while True:
                await asyncio.to_thread(app.state.deliver_customer_mail)
                await asyncio.sleep(60)

        task = asyncio.create_task(mail_loop())
        try:
            yield
        finally:
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task

    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)

    @app.exception_handler(RequestValidationError)
    async def invalid_input(request, exc):
        # Never echo submitted passwords, codes or credential values.
        return JSONResponse({"detail": "invalid_input"}, status_code=422)

    @app.middleware("http")
    async def headers(request, call_next):
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; "
            "img-src 'self' data: blob: https://tile.openstreetmap.org; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
        )
        return response

    def throttle(key):
        now = time.time()
        with db() as c:
            c.execute("BEGIN IMMEDIATE")
            c.execute("DELETE FROM attempts WHERE expires < ?", (now,))
            row = c.execute("SELECT count FROM attempts WHERE key=?", (key,)).fetchone()
            if row and row["count"] >= 8:
                raise HTTPException(429, "rate_limited")
            c.execute(
                "INSERT INTO attempts VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1",
                (key, now + 900),
            )

    def browser(request: Request):
        if request.headers.getlist("origin") != [origin]:
            raise HTTPException(403, "origin_rejected")

    def session(request: Request):
        with db() as c:
            row = c.execute(
                "SELECT * FROM sessions WHERE token=? AND expires>?",
                (digest(request.cookies.get("__Host-smarti_cloud", "")), time.time()),
            ).fetchone()
        if not row:
            raise HTTPException(401, "authentication_required")
        if request.method not in {"GET", "HEAD"}:
            browser(request)
            if not secrets.compare_digest(request.headers.get("x-csrf-token", ""), row["csrf"]):
                raise HTTPException(403, "csrf_rejected")
        return dict(row)

    def operator(request: Request):
        if not secrets.compare_digest(request.headers.get("authorization", ""), "Bearer " + provision_secret):
            raise HTTPException(403, "provisioning_denied")

    def home_auth(home_id, request):
        with db() as c:
            home = c.execute("SELECT * FROM homes WHERE id=?", (home_id,)).fetchone()
        authorization = request.headers.get("authorization", "")
        if not authorization.startswith("Bearer "):
            raise HTTPException(403, "home_authentication_failed")
        token = authorization[7:]
        if not home or not secrets.compare_digest(home["credential"], digest(token)):
            raise HTTPException(403, "home_authentication_failed")
        return home

    from .cloud_push import install_push

    install_push(app, home_auth, db)

    @app.get("/healthz")
    def health():
        return {"status": "ok"}

    @app.post("/api/register", dependencies=[Depends(browser)])
    def register(body: Registration, request: Request, background: BackgroundTasks):
        throttle("register:" + request.client.host)
        with PASSWORD_WORKERS:
            hashed = PASSWORDS.hash(body.password)
        with db() as c:
            try:
                account_id = uuid.uuid4().hex
                c.execute(
                    "INSERT INTO accounts VALUES(?,?,?)",
                    (
                        account_id,
                        body.username.lower(),
                        hashed,
                    ),
                )
                if body.profile:
                    p = body.profile
                    c.execute(
                        "INSERT INTO customer_profiles(account,email,full_name,phone,address,postal_code,city,country,photo) VALUES(?,?,?,?,?,?,?,?,?)",
                        (
                            account_id,
                            p.email,
                            p.full_name,
                            p.phone,
                            p.address,
                            p.postal_code,
                            p.city,
                            p.country,
                            p.photo,
                        ),
                    )
                c.execute(
                    "INSERT INTO customer_consents VALUES(?,?,?,?,?)",
                    (account_id, TERMS_VERSION, time.time(), int(body.marketing_opt_in), time.time()),
                )
                app.state.queue_verification(
                    c, account_id, english=request.headers.get("x-smarti-language") == "en"
                )
            except sqlite3.IntegrityError:
                raise HTTPException(409, "account_not_created") from None
        background.add_task(app.state.deliver_customer_mail)
        return {"created": True}

    @app.post("/api/login", dependencies=[Depends(browser)])
    def login(body: Credentials, request: Request, response: Response):
        throttle("login-ip:" + request.client.host)
        throttle("login-user:" + digest(body.username.lower()))
        with db() as c:
            account = c.execute(
                "SELECT * FROM accounts WHERE username=?", (body.username.lower(),)
            ).fetchone()
            with PASSWORD_WORKERS:
                valid = PASSWORDS.verify(body.password, account["password"] if account else DUMMY)
            if not account or not valid:
                raise HTTPException(401, "invalid_credentials")
            for key in ("login-ip:" + request.client.host, "login-user:" + digest(body.username.lower())):
                c.execute("UPDATE attempts SET count=MAX(0,count-1) WHERE key=?", (key,))
            token, csrf = secrets.token_urlsafe(48), secrets.token_urlsafe(32)
            c.execute("DELETE FROM sessions WHERE expires<?", (time.time(),))
            c.execute(
                "INSERT INTO sessions VALUES(?,?,?,?)",
                (
                    digest(token),
                    account["id"],
                    csrf,
                    SESSION_EXPIRY,
                ),
            )
        response.set_cookie(
            "__Host-smarti_cloud",
            token,
            secure=True,
            httponly=True,
            samesite="strict",
            max_age=SESSION_COOKIE_SECONDS,
            path="/",
        )
        return {"csrf": csrf, "username": account["username"]}

    @app.get("/api/session")
    def current(request: Request, response: Response, s=Depends(session)):
        response.set_cookie(
            "__Host-smarti_cloud",
            request.cookies["__Host-smarti_cloud"],
            secure=True,
            httponly=True,
            samesite="strict",
            path="/",
            max_age=SESSION_COOKIE_SECONDS,
        )
        return {"csrf": s["csrf"], "portal_admin": is_admin(s["account"])}

    @app.post("/api/logout")
    def logout(response: Response, s=Depends(session)):
        with db() as c:
            c.execute("DELETE FROM sessions WHERE token=?", (s["token"],))
        response.delete_cookie("__Host-smarti_cloud", secure=True, httponly=True, samesite="strict")
        return {"logged_out": True}

    @app.post("/api/provision/homes", dependencies=[Depends(operator)])
    def provision(body: HomeName):
        home_id, credential = str(uuid.uuid4()), secrets.token_urlsafe(48)
        with db() as c:
            c.execute(
                "INSERT INTO homes(id,name,credential,owner) VALUES(?,?,?,NULL)",
                (home_id, body.name, digest(credential)),
            )
        # Installer must deliver this directly to the intended hub, never to the browser.
        return {"installation_id": home_id, "credential": credential}

    @app.get("/api/hubs/{home_id}/status")
    def hub_status(home_id: str, request: Request):
        home = home_auth(home_id, request)
        with db() as c:
            allowed = remote_allowed(c, home["owner"])
        return {
            "linked": home["owner"] is not None,
            "remote_enabled": bool(home["remote_enabled"] and allowed),
        }

    @app.put("/api/hubs/{home_id}/certificate-challenge")
    def publish_challenge(home_id: str, body: CertificateChallenge, request: Request):
        home_auth(home_id, request)
        if body.validation.split(".", 1)[0] != body.token:
            raise HTTPException(422, "invalid_challenge")
        with db() as c:
            c.execute("BEGIN IMMEDIATE")
            home = c.execute("SELECT * FROM homes WHERE id=?", (home_id,)).fetchone()
            if not home["owner"] or not home["remote_enabled"]:
                raise HTTPException(403, "remote_disabled_or_unclaimed")
            c.execute("DELETE FROM certificate_challenges WHERE expires<?", (time.time(),))
            c.execute(
                "INSERT OR REPLACE INTO certificate_challenges VALUES(?,?,?,?)",
                (home_id, body.token, body.validation, time.time() + 900),
            )
        return {"published": True}

    @app.delete("/api/hubs/{home_id}/certificate-challenge/{token}")
    def clear_challenge(home_id: str, token: str, request: Request):
        home_auth(home_id, request)
        with db() as c:
            c.execute("DELETE FROM certificate_challenges WHERE home=? AND token=?", (home_id, token))
        return {"removed": True}

    @app.get("/.well-known/acme-challenge/{token}")
    def certificate_challenge(token: str, request: Request):
        # Never trust X-Forwarded-Host: only this exact home's HTTP Host selects a proof.
        host = request.headers.get("host", "").lower().removesuffix(":80")
        match = re.fullmatch(r"(?:ha-)?([0-9a-f-]{36})\.home\.smarti\.dev", host)
        if not match or len(request.headers.getlist("host")) != 1:
            raise HTTPException(404, "challenge_not_found")
        with db() as c:
            row = c.execute(
                "SELECT validation FROM certificate_challenges c JOIN homes h ON h.id=c.home "
                "WHERE c.home=? AND c.token=? AND c.expires>? AND h.owner IS NOT NULL "
                "AND h.remote_enabled=1",
                (match[1], token, time.time()),
            ).fetchone()
        if not row:
            raise HTTPException(404, "challenge_not_found")
        return PlainTextResponse(row["validation"])

    @app.delete("/api/hubs/{home_id}/claim-code")
    def cancel_claim(home_id: str, request: Request):
        home_auth(home_id, request)
        with db() as c:
            c.execute("DELETE FROM claims WHERE home=?", (home_id,))
        return {"cancelled": True}

    @app.put("/api/hubs/{home_id}/remote")
    def hub_enable(home_id: str, request: Request):
        home_auth(home_id, request)
        with db() as c:
            if c.execute(
                "SELECT 1 FROM hub_resets WHERE home=? AND phase!='completed'", (home_id,)
            ).fetchone():
                raise HTTPException(409, "onboarding_required")
            c.execute("UPDATE homes SET remote_enabled=1 WHERE id=?", (home_id,))
        return {"enabled": True}

    @app.delete("/api/hubs/{home_id}/remote")
    def hub_disable(home_id: str, request: Request):
        home_auth(home_id, request)
        with db() as c:
            c.execute("UPDATE homes SET remote_enabled=0 WHERE id=?", (home_id,))
            c.execute("DELETE FROM claims WHERE home=?", (home_id,))
        return {"disabled": True}

    @app.post("/api/hubs/{home_id}/claim-code")
    def issue(home_id: str, request: Request):
        home_auth(home_id, request)
        with db() as c:
            if c.execute("SELECT 1 FROM factory_hubs WHERE home=?", (home_id,)).fetchone():
                raise HTTPException(409, "use_hub_activation")
        code = secrets.token_urlsafe(32)
        expires = time.time() + 300
        with db() as c:
            c.execute("BEGIN IMMEDIATE")
            if c.execute("SELECT owner FROM homes WHERE id=?", (home_id,)).fetchone()["owner"]:
                raise HTTPException(409, "home_already_claimed")
            c.execute("DELETE FROM claims WHERE home=?", (home_id,))
            c.execute("INSERT INTO claims VALUES(?,?,?)", (digest(code), home_id, expires))
        return {"code": code, "expires_at": expires, "installation_id": home_id}

    @app.post("/api/homes/claim")
    def claim(body: Claim, s=Depends(session)):
        throttle("claim:" + s["account"])
        with db() as c:
            app.state.require_verified_profile(c, s["account"])
        with db() as c:
            c.execute("BEGIN IMMEDIATE")
            row = c.execute(
                "SELECT * FROM claims WHERE token=? AND expires>?", (digest(body.code), time.time())
            ).fetchone()
            if not row:
                raise HTTPException(400, "claim_invalid_or_expired")
            changed = c.execute(
                "UPDATE homes SET owner=? WHERE id=? AND owner IS NULL", (s["account"], row["home"])
            ).rowcount
            if changed != 1:
                raise HTTPException(409, "home_already_claimed")
            c.execute("DELETE FROM claims WHERE home=?", (row["home"],))
        return {"installation_id": row["home"], "linked": True}

    @app.delete("/api/homes/{home_id}/remote")
    def disable_remote(home_id: str, s=Depends(session)):
        with db() as c:
            count = c.execute(
                "UPDATE homes SET remote_enabled=0 WHERE id=? AND owner=?",
                (home_id, s["account"]),
            ).rowcount
            if count != 1:
                raise HTTPException(404, "home_not_found")
        return {"disabled": True}

    @app.get("/api/homes")
    def homes(s=Depends(session)):
        connected = set()
        if relay_status_url:
            try:
                with httpx.Client(timeout=2, trust_env=False, follow_redirects=False) as client:
                    response = client.get(relay_status_url)
                    response.raise_for_status()
                    connected = set(response.json()["connected"])
            except (httpx.HTTPError, ValueError, KeyError, TypeError):
                pass
        with db() as c:
            return [
                {
                    **{key: row[key] for key in row.keys() if key != "photo_revision"},
                    "can_manage": row["owner"] == s["account"],
                    "photo_url": (
                        "/api/customer/homes/" + row["installation_id"] + "/photo?v=" + row["photo_revision"]
                    )
                    if row["photo_revision"]
                    else None,
                    "connected": bool(
                        row["remote_enabled"]
                        and remote_allowed(c, row["owner"])
                        and remote_allowed(c, s["account"])
                        and row["installation_id"] in connected
                    ),
                    "verification_required": not remote_allowed(c, row["owner"])
                    or not remote_allowed(c, s["account"]),
                }
                for row in c.execute(
                    "SELECT id AS installation_id,name,owner,remote_enabled, (SELECT revision FROM home_photos WHERE home=homes.id) AS photo_revision, EXISTS(SELECT 1 FROM factory_hubs f WHERE f.home=homes.id) AS factory_managed, (SELECT phase FROM hub_resets r WHERE r.home=homes.id AND r.phase!='completed') AS reset_phase FROM homes WHERE owner=? OR id IN (SELECT home FROM home_members WHERE account=?) ORDER BY name",
                    (s["account"], s["account"]),
                )
            ]

    @app.put("/api/customer/homes/{home}/photo")
    def save_home_photo(home: str, body: HomePhoto, s=Depends(session)):
        with db() as c:
            c.execute("BEGIN IMMEDIATE")
            if not c.execute("SELECT 1 FROM homes WHERE id=? AND owner=?", (home, s["account"])).fetchone():
                raise HTTPException(404, "home_not_found")
            if body.photo:
                raw = base64.b64decode(body.photo.split(",", 1)[1], validate=True)
                c.execute("INSERT OR REPLACE INTO home_photos VALUES(?,?,?)", (home, raw, digest(body.photo)))
            else:
                c.execute("DELETE FROM home_photos WHERE home=?", (home,))
        return {"saved": True}

    @app.get("/api/customer/homes/{home}/photo")
    def home_photo(home: str, s=Depends(session)):
        with db() as c:
            row = c.execute(
                "SELECT p.body FROM home_photos p JOIN homes h ON h.id=p.home WHERE h.id=? "
                "AND (h.owner=? OR EXISTS(SELECT 1 FROM home_members m WHERE m.home=h.id AND m.account=?))",
                (home, s["account"], s["account"]),
            ).fetchone()
            if not row:
                raise HTTPException(404, "home_not_found")
        return Response(row["body"], media_type="image/jpeg", headers={"Cache-Control": "private, no-store"})

    install_accounts(app, db, session, home_auth, throttle, origin)
    from .cloud_energy import install_energy

    install_energy(app, db, session, home_auth)
    from .energy_sources import install_prices, install_sources

    install_sources(app, db)
    install_prices(app, db)
    is_admin = install_admin(app, db, session, relay_status_url, throttle)
    from .cloud_releases import install_releases

    install_releases(app, db, session, is_admin, home_auth)
    install_support(app, db, session, is_admin, home_auth, origin)

    install_onboarding(
        app, db, session, is_admin, home_auth, throttle, provision_secret, origin, PASSWORDS, relay_status_url
    )

    from .cloud_hub_credentials import install_hub_credentials

    install_hub_credentials(app, db, session, is_admin, home_auth)

    from .cloud_account_deletion import install_account_deletion

    install_account_deletion(app, db, session)

    @app.middleware("http")
    async def staff_destination(request: Request, call_next):
        # Route staff before customer HTML is rendered, including bookmarked pages.
        destinations = {
            "/": "/admin",
            "/account": "/admin",
            "/support": "/admin/support",
            "/support/prices": "/admin/support/prices",
            "/welcome": "/admin",
            "/activate": "/admin/hubs",
        }
        target = destinations.get(request.url.path)
        if target and request.method in {"GET", "HEAD"}:
            try:
                user = session(request)
            except HTTPException:
                user = None
            if user and is_admin(user["account"]):
                return RedirectResponse(target, status_code=303, headers={"Cache-Control": "no-store"})
        return await call_next(request)

    static = Path(__file__).with_name("cloud_web")
    app.mount("/assets", StaticFiles(directory=static), name="assets")

    @app.get("/")
    def index():
        return FileResponse(static / "index.html")

    @app.get("/privacy")
    def privacy_policy():
        return FileResponse(static / "privacy.html")

    return app


def factory():
    return create_cloud(
        os.environ.get("CLOUD_DATABASE", "/data/cloud.sqlite"),
        Path(os.environ["CLOUD_PROVISION_SECRET_FILE"]).read_text().strip(),
        os.environ.get("CLOUD_ORIGIN", "https://home.smarti.dev"),
        os.environ.get("CLOUD_RELAY_STATUS_URL"),
    )
