"""Capability-driven home preferences, still images and bounded read-only history."""

import base64
import binascii
import json
import math
from datetime import UTC, datetime, timedelta
from hashlib import sha256
from typing import Annotated, Literal, get_args
from urllib.parse import quote, urlencode

from fastapi import APIRouter, Depends, HTTPException, Response
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field, field_validator, model_validator

from .access import all_views, visible
from .ha import HAError


class LanguagePreference(BaseModel):
    model_config = {"extra": "forbid"}
    language: Literal["nb", "en"] = "nb"


class ExperiencePreference(BaseModel):
    model_config = {"extra": "forbid"}
    mode: Literal["simple", "normal", "advanced"] = "advanced"


class Preferences(BaseModel):
    model_config = {"extra": "forbid"}
    rooms: list[str] = Field(default_factory=list, max_length=12)
    energy: str | None = Field(default=None, max_length=200)
    cameras: list[str] = Field(default_factory=list, max_length=8)


class RoomViewPreferences(BaseModel):
    model_config = {"extra": "forbid"}
    hidden: list[str] = Field(default_factory=list, max_length=500)


class ModeBinding(BaseModel):
    model_config = {"extra": "forbid"}
    control_id: str | None = Field(default=None, max_length=200)


class Confirmation(BaseModel):
    confirmed: Literal[True]


RoomImageBank = Literal[
    "living",
    "bedroom",
    "kitchen",
    "bathroom",
    "attic",
    "basement",
    "garage",
    "outdoor",
    "storage",
    "laundry",
    "office",
    "hallway",
]


class RoomImage(BaseModel):
    model_config = {"extra": "forbid"}
    data: str = Field(default="", max_length=1_400_000)
    bank: RoomImageBank | None = None
    icon: RoomImageBank | None = None


class HomeAppearance(BaseModel):
    model_config = {"extra": "forbid"}
    background: Literal["auto", "living", "outdoor", "kitchen", "bedroom", "office", "custom", "none"] = (
        "auto"
    )


class HeaderImage(BaseModel):
    model_config = {"extra": "forbid"}
    data: str = Field(default="", max_length=1_400_000)


LayoutPage = Literal[
    "overview",
    "overview_simple",
    "lights",
    "climate",
    "security",
    "media",
    "misc",
    "energy",
    "energy_history",
    "energy_control",
]
LayoutSurface = Literal["desktop", "mobile"]


class CardConfig(BaseModel):
    model_config = {"extra": "forbid", "strict": True}
    type: Literal["auto", "compact", "picture", "graph", "clock", "horizon", "daylight", "moon", "date"] = (
        "auto"
    )
    title: str = Field(default="", max_length=80)
    icon: Literal[
        "auto",
        "light",
        "energy",
        "temperature",
        "humidity",
        "security",
        "lock",
        "camera",
        "media",
        "plug",
        "blinds",
        "home",
        "room",
        "calendar",
        "people",
        "routine",
        "graph",
        "battery",
        "fan",
        "sensor",
        "clock",
        "sun",
        "moon",
    ] = "auto"
    image: Literal[
        "auto",
        "none",
        "living",
        "kitchen",
        "bedroom",
        "outdoor",
        "office",
        "pendant",
        "plug",
        "lock",
        "contact",
        "equipment-leak",
        "equipment-motion",
        "equipment-movement",
        "equipment-presence",
        "equipment-window-closed",
        "equipment-window-open",
        "equipment-calendar",
        "equipment-charger",
        "equipment-switch",
        "equipment-strip",
        "equipment-outdoor",
        "equipment-spot",
        "equipment-track",
        "equipment-ceiling",
        "equipment-smoke",
        "equipment-bulb",
        "equipment-floor",
        "equipment-desk",
        "equipment-thermostat",
        "equipment-air-conditioner",
        "equipment-fan",
        "equipment-blind",
        "equipment-roller",
        "equipment-curtain",
        "equipment-awning",
        "equipment-garage",
        "equipment-alarm",
        "equipment-meter",
        "equipment-money",
        "equipment-backup",
        "equipment-environment",
        "equipment-data",
        "equipment-battery",
    ] = "auto"
    sources: list[
        Annotated[str, Field(min_length=3, max_length=250, pattern=r"^[a-z_]+\.[a-zA-Z0-9_]+$")]
    ] = Field(default_factory=list, max_length=6)
    period: Literal["6", "24", "168"] = "24"
    clock_style: Literal["digital", "analog", "orbital"] | None = None
    show_seconds: bool | None = None
    time_format: Literal["24h", "12h"] | None = None

    @field_validator("title")
    @classmethod
    def readable_title(cls, value):
        if value and not value.isprintable():
            raise ValueError("Card titles must be printable")
        return value.strip()

    @model_validator(mode="after")
    def valid_sources(self):
        if self.type in {"clock", "horizon", "daylight", "moon", "date"}:
            if self.sources:
                raise ValueError("Time and sky cards do not bind device sources")
        elif self.type != "auto" and not self.sources:
            raise ValueError("Choose a data source")
        if self.type != "clock" and any(
            value is not None for value in [self.clock_style, self.show_seconds, self.time_format]
        ):
            raise ValueError("Clock options require a clock card")
        if len(self.sources) != len(set(self.sources)):
            raise ValueError("Duplicate data sources")
        if self.type != "graph" and len(self.sources) > 1:
            raise ValueError("Only graphs support several data sources")
        return self


class LayoutItem(BaseModel):
    model_config = {"extra": "forbid", "strict": True}
    id: str = Field(min_length=1, max_length=250)
    x: int = Field(ge=0, le=2)
    y: int = Field(ge=0, le=1999)
    w: int = Field(ge=1, le=3)
    h: int = Field(ge=1, le=4)
    config: CardConfig | None = None

    @field_validator("id")
    @classmethod
    def printable_id(cls, value):
        if not value.isprintable():
            raise ValueError("Card identifiers must be printable")
        return value


class HomeLayout(BaseModel):
    model_config = {"extra": "forbid", "strict": True}
    revision: int = Field(ge=0)
    items: list[LayoutItem] = Field(max_length=300)
    group_by_room: bool | None = None

    @model_validator(mode="after")
    def fits_grid(self):
        ids, occupied = set(), set()
        for item in self.items:
            if item.id in ids or item.x + item.w > 3 or item.y + item.h > 2000:
                raise ValueError("Duplicate card or card outside grid")
            ids.add(item.id)
            cells = {(x, y) for x in range(item.x, item.x + item.w) for y in range(item.y, item.y + item.h)}
            if cells & occupied:
                raise ValueError("Cards must not overlap")
            occupied.update(cells)
        return self


def home_router(store, user, ha, settings):
    router = APIRouter(prefix="/api/home")

    def admin(current):
        if current["role"] != "admin":
            raise HTTPException(403, "admin_required")

    def control(id):
        found = next((c for c in ha.controls() if c.id == id or c.entity_id == id), None)
        if not found:
            raise HTTPException(404, "entity_not_found")
        return found

    @router.get("/language")
    async def language(current=Depends(user)):
        return LanguagePreference.model_validate_json(store.get(f"language:{current['id']}", "{}"))

    @router.put("/language")
    async def save_language(body: LanguagePreference, current=Depends(user)):
        store.set(f"language:{current['id']}", body.model_dump_json())
        return body

    @router.get("/experience")
    async def experience(current=Depends(user)):
        return ExperiencePreference.model_validate_json(store.get(f"experience:{current['id']}", "{}"))

    @router.put("/experience")
    async def save_experience(body: ExperiencePreference, current=Depends(user)):
        store.set(f"experience:{current['id']}", body.model_dump_json())
        return body

    def appearance_value(current):
        pref = HomeAppearance.model_validate_json(store.get(f"home_appearance:{current['id']}", "{}"))
        data = store.get(f"home_background:{current['id']}", "")
        return {
            **pref.model_dump(),
            "has_custom": bool(data),
            "image_version": sha256(data.encode()).hexdigest()[:16] if data else None,
        }

    @router.get("/appearance")
    async def appearance(current=Depends(user)):
        return appearance_value(current)

    @router.get("/layout/{page}")
    async def home_layout(page: LayoutPage, surface: LayoutSurface = "desktop", current=Depends(user)):
        prefix = "home_layout_mobile" if surface == "mobile" else "home_layout"
        saved = store.get(f"{prefix}:{current['id']}:{page}")
        if not saved and page == "energy_control":
            from .energy_layout import combined_layout

            legacy = [store.get(f"{prefix}:{current['id']}:{old}") for old in ("energy", "energy_history")]
            return combined_layout(*(json.loads(value) if value else None for value in legacy))
        return json.loads(saved) if saved else {"revision": 0, "items": None}

    @router.put("/layout/{page}")
    async def save_home_layout(
        page: LayoutPage, body: HomeLayout, surface: LayoutSurface = "desktop", current=Depends(user)
    ):
        if body.group_by_room and page not in {"lights", "misc", "climate", "security", "media"}:
            raise HTTPException(422, "room_grouping_not_supported")
        prefix = "home_layout_mobile" if surface == "mobile" else "home_layout"
        key = f"{prefix}:{current['id']}:{page}"
        entities = {c.entity_id: c for c in ha.controls()}
        for item in body.items:
            if item.id.startswith("custom:") and not (
                item.config
                and (
                    item.config.sources
                    or item.config.type in {"clock", "horizon", "daylight", "moon", "date"}
                )
            ):
                raise HTTPException(422, "card_source_required")
            for source in item.config.sources if item.config else []:
                if source in entities and not visible(current, entities[source]):
                    raise HTTPException(403, "permission_denied")
        # Compare and save atomically so a second browser cannot silently replace an edit.
        with store.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
            previous = json.loads(row[0]) if row else {}
            revision = previous.get("revision", 0)
            if revision != body.revision:
                raise HTTPException(409, "layout_changed")
            result = {
                "revision": revision + 1,
                "items": [item.model_dump(exclude_none=True) for item in body.items],
            }
            if body.group_by_room is not None:
                result["group_by_room"] = body.group_by_room
            elif "group_by_room" in previous:
                result["group_by_room"] = previous["group_by_room"]
            db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES (?,?)", (key, json.dumps(result)))
        return result

    @router.put("/appearance")
    async def save_appearance(body: HomeAppearance, current=Depends(user)):
        if body.background == "custom" and not store.get(f"home_background:{current['id']}"):
            raise HTTPException(422, "image_not_found")
        store.set(f"home_appearance:{current['id']}", body.model_dump_json())
        return appearance_value(current)

    @router.put("/appearance/image")
    async def save_header_image(body: HeaderImage, current=Depends(user)):
        if body.data:
            try:
                raw = base64.b64decode(body.data, validate=True)
                if len(raw) > 1_000_000 or not (
                    raw.startswith(b"\xff\xd8\xff") or raw.startswith(b"\x89PNG\r\n\x1a\n")
                ):
                    raise ValueError()
            except (ValueError, binascii.Error):
                raise HTTPException(422, "invalid_image") from None
        # Personal appearance uses the same settings store as the other Home preferences.
        # Save the image and selected background together; leave every other setting intact.
        with store.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            for key, value in (
                (f"home_background:{current['id']}", body.data),
                (
                    f"home_appearance:{current['id']}",
                    HomeAppearance(background="custom" if body.data else "auto").model_dump_json(),
                ),
            ):
                db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES (?,?)", (key, value))
        return appearance_value(current)

    @router.get("/appearance/image")
    async def header_image(current=Depends(user)):
        data = store.get(f"home_background:{current['id']}", "")
        if not data:
            raise HTTPException(404, "image_not_found")
        raw = base64.b64decode(data)
        return Response(
            raw,
            media_type="image/png" if raw.startswith(b"\x89PNG") else "image/jpeg",
            headers={"Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff"},
        )

    @router.get("/preferences")
    async def preferences(current=Depends(user)):
        with store.connect() as db:
            images = {
                row[0][11:]: bool(row[1])
                for row in db.execute("SELECT key,length(value) FROM settings WHERE key LIKE 'room_image:%'")
            }
        pref = Preferences.model_validate_json(
            store.get(f"home_preferences:{current['id']}", "{}")
        ).model_dump()
        allowed = {key for c in ha.controls() if visible(current, c) for key in (c.id, c.entity_id)}
        pref["cameras"] = [id for id in pref["cameras"] if id in allowed]
        if pref.get("energy") not in allowed:
            pref["energy"] = None
        return {
            **pref,
            "modes": json.loads(store.get("home_modes", "{}")) if all_views(current) else {},
            "images": {id: images.get(id, False) for id in ha.areas},
            "icons": {
                id: store.get("room_image:" + id).removeprefix("icon:")
                for id in ha.areas
                if (store.get("room_image:" + id) or "").startswith("icon:")
            },
        }

    @router.put("/preferences")
    async def save_preferences(body: Preferences, current=Depends(user)):
        if any(id not in ha.areas for id in body.rooms):
            raise HTTPException(422, "area_not_found")
        if body.energy:
            c = control(body.energy)
            if c.domain != "sensor" or c.attributes.get("unit_of_measurement") not in {
                "W",
                "kW",
                "Wh",
                "kWh",
            }:
                raise HTTPException(422, "invalid_meter")
        if any(control(id).domain != "camera" for id in body.cameras):
            raise HTTPException(422, "invalid_camera")
        store.set(f"home_preferences:{current['id']}", body.model_dump_json())
        return {"saved": True}

    @router.get("/room-view/{id}")
    async def room_view(id: str, current=Depends(user)):
        if id not in ha.areas:
            raise HTTPException(404, "area_not_found")
        return RoomViewPreferences.model_validate_json(
            store.get(f"room_view:{current['id']}:{id}", "{}")
        ).model_dump()

    @router.put("/room-view/{id}")
    async def save_room_view(id: str, body: RoomViewPreferences, current=Depends(user)):
        if id not in ha.areas:
            raise HTTPException(404, "area_not_found")
        allowed = {c.entity_id for c in ha.controls() if c.area_id == id}
        if any(entity not in allowed for entity in body.hidden):
            raise HTTPException(422, "entity_not_in_room")
        body.hidden = list(dict.fromkeys(body.hidden))
        store.set(f"room_view:{current['id']}:{id}", body.model_dump_json())
        return body.model_dump()

    @router.put("/modes/{mode}")
    async def bind_mode(
        mode: Literal["home", "away", "night", "holiday"], body: ModeBinding, current=Depends(user)
    ):
        admin(current)
        if body.control_id and control(body.control_id).domain not in {"scene", "script", "automation"}:
            raise HTTPException(422, "invalid_mode")
        # Read and write under one transaction to preserve concurrent edits to other modes.
        with store.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT value FROM settings WHERE key='home_modes'").fetchone()
            modes = json.loads(row[0]) if row else {}
            modes[mode] = body.control_id
            db.execute("INSERT OR REPLACE INTO settings VALUES ('home_modes',?)", (json.dumps(modes),))
        return {"saved": True}

    @router.post("/modes/{mode}/run")
    async def run_mode(
        mode: Literal["home", "away", "night", "holiday"], body: Confirmation, current=Depends(user)
    ):
        id = json.loads(store.get("home_modes", "{}")).get(mode)
        if not id:
            raise HTTPException(409, "mode_not_configured")
        c = control(id)
        if not ha.connected or c.availability != "available":
            raise HTTPException(409, "device_unavailable")
        if c.domain not in {"scene", "script", "automation"}:
            raise HTTPException(422, "invalid_mode")
        if settings.mode == "demo":
            return {"status": "simulated"}
        try:
            await ha.request(
                "call_service",
                domain=c.domain,
                service="trigger" if c.domain == "automation" else "turn_on",
                target={"entity_id": c.entity_id},
                service_data={"skip_condition": False} if c.domain == "automation" else {},
            )
            return {"status": "accepted_unconfirmed"}
        except (HAError, TimeoutError):
            raise HTTPException(504, "command_unconfirmed_do_not_retry_automatically") from None

    @router.put("/room-image/{id}")
    async def room_image(id: str, body: RoomImage, current=Depends(user)):
        admin(current)
        if id not in ha.areas:
            raise HTTPException(404, "area_not_found")
        if sum(bool(value) for value in (body.data, body.bank, body.icon)) > 1:
            raise HTTPException(422, "choose_one_room_visual")
        if body.icon:
            store.set("room_image:" + id, "icon:" + body.icon)
            return {"saved": True}
        if body.bank:
            if body.data:
                raise HTTPException(422, "choose_one_image")
            store.set("room_image:" + id, "bank:" + body.bank)
            return {"saved": True}
        if body.data:
            try:
                data = base64.b64decode(body.data, validate=True)
                if len(data) > 1_000_000 or not (
                    data.startswith(b"\xff\xd8\xff") or data.startswith(b"\x89PNG\r\n\x1a\n")
                ):
                    raise ValueError()
            except (ValueError, binascii.Error):
                raise HTTPException(422, "invalid_image") from None
        store.set("room_image:" + id, body.data)
        return {"saved": True}

    @router.get("/room-image/{id}")
    async def image(id: str, current=Depends(user)):
        if id not in ha.areas:
            raise HTTPException(404, "area_not_found")
        data = store.get("room_image:" + id)
        if not data:
            raise HTTPException(404, "image_not_found")
        if data.startswith("icon:"):
            choice = data.removeprefix("icon:")
            if choice not in get_args(RoomImageBank):
                raise HTTPException(404, "image_not_found")
            path = settings.static_dir / "room-icons" / f"{choice}.svg"
            if not path.is_file():
                raise HTTPException(404, "image_not_found")
            return FileResponse(
                path, media_type="image/svg+xml", headers={"Cache-Control": "private, no-store"}
            )
        if data.startswith("bank:"):
            choice = data.removeprefix("bank:")
            if choice not in get_args(RoomImageBank):
                raise HTTPException(404, "image_not_found")
            path = settings.static_dir / "home" / f"home-{choice}.webp"
            if not path.is_file():
                raise HTTPException(404, "image_not_found")
            return FileResponse(path, media_type="image/webp", headers={"Cache-Control": "private, no-store"})
        raw = base64.b64decode(data)
        return Response(
            raw,
            media_type="image/png" if raw.startswith(b"\x89PNG") else "image/jpeg",
            headers={"Cache-Control": "private, no-store"},
        )

    @router.get("/camera/{id}")
    async def camera(id: str, current=Depends(user)):
        c = control(id)
        if c.domain != "camera":
            raise HTTPException(404, "camera_not_found")
        if settings.mode == "demo" or c.availability != "available":
            raise HTTPException(503, "camera_unavailable")
        try:
            data, media_type = await ha.camera_image(c.entity_id)
            return Response(data, media_type=media_type, headers={"Cache-Control": "private, no-store"})
        except HAError:
            raise HTTPException(503, "camera_unavailable") from None

    @router.get("/history/{id}")
    async def history(id: str, current=Depends(user)):
        c = control(id)
        if c.domain != "sensor" or c.attributes.get("unit_of_measurement") not in {"W", "kW", "Wh", "kWh"}:
            raise HTTPException(422, "invalid_meter")
        if settings.mode == "demo":
            return {"points": [], "unit": c.attributes.get("unit_of_measurement")}
        start = datetime.now(UTC) - timedelta(hours=24)
        try:
            rows = await ha.rest(
                "GET",
                "history/period/"
                + quote(start.isoformat(), safe="")
                + "?"
                + urlencode({"filter_entity_id": c.entity_id, "no_attributes": "", "minimal_response": ""}),
            )
        except (HAError, TimeoutError):
            raise HTTPException(503, "history_unavailable") from None
        points = []
        for row in rows[0] if rows else []:
            try:
                value = float(row["state"])
                time = datetime.fromisoformat(row["last_changed"])
                if math.isfinite(value):
                    points.append({"time": time.isoformat(), "value": value})
            except (ValueError, TypeError, KeyError):
                # Explicit gap: never draw a continuous line across an unknown reading.
                points.append({"time": row.get("last_changed"), "value": None})
        # Return a bounded series; history UI never claims daily usage from cumulative totals.
        stride = max(1, math.ceil(len(points) / 300))
        sampled = []
        for index in range(0, len(points), stride):
            bucket = points[index : index + stride]
            sampled.append(next((p for p in bucket if p["value"] is None), bucket[-1]))
        return {"points": sampled, "unit": c.attributes.get("unit_of_measurement")}

    @router.get("/energy-sources")
    async def energy_sources(current=Depends(user)):
        if settings.mode == "demo" or not ha.connected:
            return []
        try:
            config = await ha.request("energy/get_prefs")
        except (HAError, TimeoutError):
            return []
        controls = {c.entity_id: c for c in ha.controls() if visible(current, c)}
        result = []
        for source in (config or {}).get("energy_sources", []):
            if source.get("type") not in {"solar", "battery"}:
                continue
            for field in ["stat_rate", "stat_soc", "stat_energy_from", "stat_energy_to"]:
                c = controls.get(source.get(field))
                if c:
                    result.append({"id": c.id, "type": source["type"], "measurement": field})
        for source in (config or {}).get("device_consumption", []):
            c = controls.get(source.get("stat_rate") or source.get("stat_consumption"))
            if c:
                result.append({"id": c.id, "type": "consumer", "measurement": "meter"})
        return result[:30]

    @router.get("/activity")
    async def activity(current=Depends(user)):
        controls = {c.entity_id: c for c in ha.controls() if visible(current, c)}
        return [
            e
            for e in ha.activity
            if e["entity_id"] in controls
            and (
                controls[e["entity_id"]].domain in {"lock", "binary_sensor", "climate", "alarm_control_panel"}
                or e["state"] in {"unavailable", "unknown"}
            )
        ][:20]

    return router
